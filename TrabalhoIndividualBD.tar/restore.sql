--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE delegacia;
--
-- Name: delegacia; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE delegacia WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE delegacia OWNER TO postgres;

\connect delegacia

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: delegacia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delegacia (
    delegacia_id integer NOT NULL,
    del_nome character varying(50),
    "del_endereço" character varying(200),
    del_telefone integer
);


ALTER TABLE public.delegacia OWNER TO postgres;

--
-- Name: delegacia_delegacia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.delegacia_delegacia_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.delegacia_delegacia_id_seq OWNER TO postgres;

--
-- Name: delegacia_delegacia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.delegacia_delegacia_id_seq OWNED BY public.delegacia.delegacia_id;


--
-- Name: denuncia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.denuncia (
    denuncia_id integer NOT NULL,
    den_dt_data date,
    den_descri character varying(200),
    den_local character varying(200),
    fk_delegacia_id integer
);


ALTER TABLE public.denuncia OWNER TO postgres;

--
-- Name: denuncia_denuncia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.denuncia_denuncia_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.denuncia_denuncia_id_seq OWNER TO postgres;

--
-- Name: denuncia_denuncia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.denuncia_denuncia_id_seq OWNED BY public.denuncia.denuncia_id;


--
-- Name: denunciante; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.denunciante (
    denunciante_id integer NOT NULL,
    d_nome character varying(50),
    d_cpf character varying(14),
    "d_endereço" character varying(200),
    d_telefone integer,
    d_data_nasc date
);


ALTER TABLE public.denunciante OWNER TO postgres;

--
-- Name: denunciante_denunciante_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.denunciante_denunciante_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.denunciante_denunciante_id_seq OWNER TO postgres;

--
-- Name: denunciante_denunciante_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.denunciante_denunciante_id_seq OWNED BY public.denunciante.denunciante_id;


--
-- Name: delegacia delegacia_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delegacia ALTER COLUMN delegacia_id SET DEFAULT nextval('public.delegacia_delegacia_id_seq'::regclass);


--
-- Name: denuncia denuncia_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.denuncia ALTER COLUMN denuncia_id SET DEFAULT nextval('public.denuncia_denuncia_id_seq'::regclass);


--
-- Name: denunciante denunciante_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.denunciante ALTER COLUMN denunciante_id SET DEFAULT nextval('public.denunciante_denunciante_id_seq'::regclass);


--
-- Data for Name: delegacia; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3338.dat

--
-- Data for Name: denuncia; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3340.dat

--
-- Data for Name: denunciante; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3336.dat

--
-- Name: delegacia_delegacia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.delegacia_delegacia_id_seq', 1, false);


--
-- Name: denuncia_denuncia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.denuncia_denuncia_id_seq', 1, false);


--
-- Name: denunciante_denunciante_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.denunciante_denunciante_id_seq', 1, false);


--
-- Name: delegacia delegacia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delegacia
    ADD CONSTRAINT delegacia_pkey PRIMARY KEY (delegacia_id);


--
-- Name: denuncia denuncia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.denuncia
    ADD CONSTRAINT denuncia_pkey PRIMARY KEY (denuncia_id);


--
-- Name: denunciante denunciante_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.denunciante
    ADD CONSTRAINT denunciante_pkey PRIMARY KEY (denunciante_id);


--
-- Name: denuncia denuncia_fk_delegacia_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.denuncia
    ADD CONSTRAINT denuncia_fk_delegacia_id_fkey FOREIGN KEY (fk_delegacia_id) REFERENCES public.delegacia(delegacia_id);


--
-- PostgreSQL database dump complete
--

